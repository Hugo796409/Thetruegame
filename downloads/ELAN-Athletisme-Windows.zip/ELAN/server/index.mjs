import { createApp } from './app.mjs';
import { defaultDbPath } from './db.mjs';

const {app,db}=createApp();
const port=Number(process.env.PORT || 4173);
const host=process.env.HOST || '0.0.0.0';
if(!Number.isInteger(port) || port<1 || port>65535) throw new Error('PORT doit être compris entre 1 et 65535.');
const server=app.listen(port,host,()=>{
  console.log(`ÉLAN est lancé sur le port ${port}. Ouvre http://localhost:${port} sur cet ordinateur.`);
  console.log(`Données conservées dans ${process.env.ELAN_DB_PATH || defaultDbPath}`);
});
server.on('error',error=>{console.error(`Impossible de démarrer ÉLAN : ${error.message}`);process.exitCode=1;db.close();});
for(const signal of ['SIGINT','SIGTERM']) process.on(signal,()=>server.close(()=>{db.close();process.exit(0);}));
