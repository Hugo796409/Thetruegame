import * as cheerio from 'cheerio';
import { createHash } from 'node:crypto';
import { ProxyAgent } from 'undici';

const HOSTS = new Set(['bases.athle.fr', 'athle.fr', 'www.athle.fr']);
const MAX_BYTES = 4 * 1024 * 1024;
let proxy;
function dispatcher() {
  const address = process.env.HTTPS_PROXY || process.env.https_proxy;
  if (!address) return undefined;
  proxy ||= new ProxyAgent(address);
  return proxy;
}

export class FfaError extends Error {
  constructor(message, code = 'FFA_UNAVAILABLE', sourceUrl) {
    super(message); this.code = code; this.sourceUrl = sourceUrl;
  }
}

export function validateFfaUrl(value, athleteOnly = true) {
  let url;
  try { url = new URL(value); } catch { throw new FfaError('Le lien FFA est invalide.', 'FFA_URL_INVALID'); }
  if (url.protocol !== 'https:' || !HOSTS.has(url.hostname) || url.port || url.username || url.password || url.hash)
    throw new FfaError('Utilise un lien HTTPS public officiel athle.fr, sans port ni identifiants.', 'FFA_URL_INVALID');
  if (athleteOnly && !((url.hostname === 'bases.athle.fr' && /^\/asp\.net\/athletes\.aspx$/i.test(url.pathname) && /^[\w-]{1,160}$/.test(url.searchParams.get('seq') || '')) ||
    (/^\/athletes?\/[\w-]{1,160}\/?$/i.test(url.pathname))))
    throw new FfaError('Colle le lien de la fiche athlète FFA (athletes.aspx avec seq, ou /athletes/identifiant).', 'FFA_URL_INVALID');
  return url;
}

async function fetchOfficial(value) {
  let url = validateFfaUrl(value, false);
  for (let hop = 0; hop < 4; hop++) {
    let response;
    try {
      response = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(20_000),
        headers: { 'User-Agent': 'ElanAthletics/1.0 (personal training companion)', 'Accept': 'text/html' },
        dispatcher: dispatcher() });
    } catch {
      throw new FfaError('La FFA est inaccessible depuis ce serveur. Vérifie Internet ou réessaie plus tard ; aucun résultat fictif n’a été ajouté.', 'FFA_UNAVAILABLE', String(url));
    }
    if ([301,302,303,307,308].includes(response.status)) {
      const location = response.headers.get('location');
      await response.body?.cancel().catch(() => {});
      if (!location) throw new FfaError('Redirection FFA invalide.', 'FFA_UNAVAILABLE', String(url));
      url = validateFfaUrl(String(new URL(location, url)), false);
      continue;
    }
    if (!response.ok) throw new FfaError(`Le service FFA a répondu ${response.status}. Réessaie plus tard ou importe un fichier CSV.`, 'FFA_UNAVAILABLE', String(url));
    if (Number(response.headers.get('content-length')) > MAX_BYTES)
      throw new FfaError('La réponse FFA est trop volumineuse.', 'FFA_FORMAT_CHANGED', String(url));
    const chunks = []; let size = 0;
    for await (const chunk of response.body) {
      size += chunk.length;
      if (size > MAX_BYTES) { await response.body.cancel().catch(() => {}); throw new FfaError('La réponse FFA est trop volumineuse.', 'FFA_FORMAT_CHANGED', String(url)); }
      chunks.push(chunk);
    }
    const buffer = Buffer.concat(chunks);
    const contentType = response.headers.get('content-type') || '';
    const sniff = buffer.subarray(0, 2048).toString('ascii');
    const encoding = /(?:iso-8859-1|windows-1252)/i.test(contentType + sniff) ? 'windows-1252' : 'utf-8';
    return { html: new TextDecoder(encoding).decode(buffer), url: String(url) };
  }
  throw new FfaError('Trop de redirections FFA.', 'FFA_UNAVAILABLE', String(url));
}

const tidy = text => String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const compact = text => tidy(text).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export function parseDate(text) {
  const match = tidy(text).match(/\b(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})\b/);
  if (!match) return null;
  let [, day, month, year] = match;
  if (year.length === 2) year = Number(year) > 70 ? `19${year}` : `20${year}`;
  const value = `${year}-${month.padStart(2,'0')}-${day.padStart(2,'0')}`;
  const check = new Date(value + 'T12:00:00Z');
  return !Number.isNaN(check.valueOf()) && check.toISOString().slice(0,10) === value ? value : null;
}

export function canonicalEvent(text) {
  const value = compact(text).replace(/\s+/g,'').replace(/(?:-|\()?salle\)?$/,'');
  if (/marche/.test(value)) {
    const distance = value.match(/(?:5|10|20)(?=km)/)?.[0] || (value.match(/^(5000|10000|20000)m/) ? String(Number(value.match(/^\d+/)[0])/1000) : null);
    return distance ? 'walk'+distance : null;
  }
  if (/^(?:50|60|80|100|110|200|300|400|800|1000|1500|2000|3000|5000|10000)m(?:haies|h)?(?:\([^)]*\))?(?:\/.*)?$/.test(value)) {
    const distance = value.match(/^\d+/)[0];
    return distance + 'm' + (/haies|h(?:\(|$)/.test(value) ? 'h' : '');
  }
  if (/^(?:2000|3000)m(?:steeple|sc)/.test(value)) return value.match(/^\d+/)[0] + 'msc';
  if (/semi/.test(value)) return 'half';
  if (/^marathon/.test(value)) return 'marathon';
  if (/^(5|10|15|20)km/.test(value)) return value.match(/^\d+/)[0] + 'km';
  if (/longueur/.test(value)) return 'long';
  if (/triple/.test(value)) return 'triple';
  if (/hauteur/.test(value)) return 'high';
  if (/perche/.test(value)) return 'pole';
  if (/poids/.test(value)) return 'shot';
  if (/disque/.test(value)) return 'discus';
  if (/marteau/.test(value)) return 'hammer';
  if (/javelot/.test(value)) return 'javelin';
  if (/decathlon/.test(value)) return 'decathlon';
  if (/heptathlon/.test(value)) return 'heptathlon';
  if (/pentathlon/.test(value)) return 'pentathlon';
  return null;
}

export function parseMark(raw, event) {
  let text = tidy(raw).replace(/[’′]/g,"'").replace(/[“”″]/g,'"').replace(/\s*pts?\.?$/i,'').replace(/\s*m$/i,'').trim();
  if (!text || /^(?:dnf|dns|dq|nm|nc|ab|np|irr|x|-)$/i.test(text)) return null;
  const isTime = /^(?:\d+m|\d+km|half|marathon|walk)/i.test(event);
  if (!isTime) {
    text = text.replace(/^(\d+)m(\d{1,2})$/i, '$1.$2');
    if (!/^\d+(?:[.,]\d{1,3})?$/.test(text)) return null;
    const value = Number(text.replace(',','.'));
    return value > 0 ? value : null;
  }
  text = text.replace(/''/g,'.').replace(/"/g,'.').replace(/h/g,':').replace(/'/g,':').replace(/,$/,'').replace(/\.$/,'');
  if (!/^\d+(?:[:.,]\d+){0,3}$/.test(text)) return null;
  const parts = text.replace(',','.').split(':').map(Number);
  if (parts.some(n=>!Number.isFinite(n) || n < 0) || parts.length > 3) return null;
  if (parts.length > 1 && parts.slice(1).some(n=>n >= 60)) return null;
  const value = Math.round(parts.reduce((total,n)=>total*60+n,0)*1e6)/1e6;
  return value > 0 ? value : null;
}

export function parseAthleteHtml(html, sourceUrl) {
  validateFfaUrl(sourceUrl);
  const $ = cheerio.load(html);
  if (/captcha|cloudflare|access denied|accès refusé/i.test($('title').text()))
    throw new FfaError('La FFA demande une vérification humaine. Ouvre la fiche officielle puis utilise un CSV.', 'FFA_UNAVAILABLE', sourceUrl);
  const performances = [];
  const seen = new Set();
  $('tr').each((_, row) => {
    const cells = $(row).children('td').map((__,cell)=>tidy($(cell).text())).get();
    if (cells.length < 3) return;
    const eventIndex = cells.findIndex(cell=>canonicalEvent(cell));
    const dateIndex = cells.findIndex(cell=>parseDate(cell));
    if (eventIndex < 0 || dateIndex < 0) return;
    const event = canonicalEvent(cells[eventIndex]);
    // On the public FFA tables, the performance follows the event. Never treat
    // classement/points columns before the event as a result.
    const markIndex = eventIndex + 1;
    if (markIndex === dateIndex || markIndex >= cells.length) return;
    const value = parseMark(cells[markIndex], event);
    if (value === null) return;
    const date = parseDate(cells[dateIndex]);
    const windText = cells.slice(markIndex+1).find(cell=>/^[+-]\d[.,]\d(?:\s*m\/s)?$/.test(cell));
    const wind = windText ? Number(windText.replace(',','.').replace(/m\/s/g,'').trim()) : null;
    const venue = cells[dateIndex + 1] && !/^\d+$/.test(cells[dateIndex+1]) ? cells[dateIndex+1] : '';
    const identity = [sourceUrl, event, value, date, venue, wind].join('|');
    if (seen.has(identity)) return;
    seen.add(identity);
    performances.push({ id: 'ffa-' + createHash('sha256').update(identity).digest('hex').slice(0,20), event, value, date, venue, wind, source: 'FFA', sourceUrl });
  });
  const heading = tidy($('h1').first().text() || $('.athlete-name').first().text() || $('title').text().replace(/\s*[-|]\s*(?:FFA|Fédération.*)$/i,''));
  const club = tidy($('[data-club], .athlete-club').first().text());
  if (!performances.length) throw new FfaError('Aucune ligne de performance datée reconnue. La page est peut-être vide, limitée ou son format a changé ; importe un CSV ou saisis tes résultats.', 'FFA_FORMAT_CHANGED', sourceUrl);
  return { athlete: { name: heading || 'Athlète FFA', club, url: sourceUrl }, performances: performances.sort((a,b)=>b.date.localeCompare(a.date)), fetchedAt: new Date().toISOString(), warnings: ['Seules les performances datées présentes dans cette page sont importées. Vérifie la saison, les engins et les conditions sur la source FFA.'] };
}

export async function importAthlete(url) {
  const verified = String(validateFfaUrl(url));
  const result = await fetchOfficial(verified);
  return parseAthleteHtml(result.html, result.url);
}

export async function searchAthletes(surname, givenName = '', club = '', year = new Date().getFullYear()) {
  const url = new URL('https://bases.athle.fr/asp.net/liste.aspx');
  const params = { frmbase:'bilans',frmmode:'1',frmespace:'0',frmsaison:String(year),frmnom:tidy(surname),frmprenom:tidy(givenName),frmclub:tidy(club) };
  for (const [key,value] of Object.entries(params)) url.searchParams.set(key,value);
  const response = await fetchOfficial(String(url));
  const $ = cheerio.load(response.html); const candidates = new Map();
  $('a[href]').each((_, node)=>{
    let candidate;
    try { candidate = String(validateFfaUrl(String(new URL($(node).attr('href'), response.url)))); } catch { return; }
    const label = tidy($(node).text());
    if (!label || label.length < 3) return;
    const row = tidy($(node).closest('tr').text());
    candidates.set(candidate, { name: label, club: club && compact(row).includes(compact(club)) ? tidy(club) : '', context: row.slice(0,240), url:candidate });
  });
  return { athletes: [...candidates.values()].slice(0,50), searchUrl: String(url), note: 'Recherche dans les bilans de la saison choisie. Confirme toujours le nom et le club ; aucun profil n’est lié automatiquement.' };
}

export function mergePerformances(existing, incoming) {
  const values = new Map();
  for (const item of [...existing,...incoming]) values.set(item.id, item);
  return [...values.values()].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
}
