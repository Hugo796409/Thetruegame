import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createApp } from '../app.mjs';
import { openDb } from '../db.mjs';
import { canonicalEvent, parseAthleteHtml, parseDate, parseMark, validateFfaUrl, mergePerformances } from '../ffa.mjs';

async function setup(t, options={}) {
  const db=openDb(':memory:');
  const {app}=createApp({db,rateLimit:false,...options});
  const server=app.listen(0,'127.0.0.1');
  await once(server,'listening');
  const base=`http://127.0.0.1:${server.address().port}`;
  t.after(()=>new Promise(resolve=>server.close(()=>{db.close();resolve();})));
  const api=async(path,{method='GET',body,cookie,headers={}}={})=>{
    const response=await fetch(base+path,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...headers},body:body?JSON.stringify(body):undefined});
    return {status:response.status,json:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0],headers:response.headers};
  };
  return {api,db,base};
}

test('registration, protected state, account isolation, revision conflict and login persistence',async t=>{
  const {api,db}=await setup(t);
  assert.equal((await api('/api/health')).json.status,'ok');
  assert.deepEqual((await api('/api/auth/me')).json,{user:null});
  assert.equal((await api('/api/state')).status,401);
  const first=await api('/api/auth/register',{method:'POST',body:{name:'Athlète A',email:'a@example.com',password:'motdepasse-solide'}});
  assert.equal(first.status,201);
  assert.match(first.cookie,/^elan_session=[a-f0-9]{64}$/);
  assert.match(first.headers.get('set-cookie'),/HttpOnly/);
  assert.equal(first.json.user.email,'a@example.com');
  assert.equal('password_hash' in first.json.user,false);
  assert.notEqual(db.prepare('SELECT password_hash FROM users').get().password_hash,'motdepasse-solide');
  assert.deepEqual((await api('/api/state',{cookie:first.cookie})).json,{state:null,revision:0});
  const state={profile:{name:'A'},performances:[{event:'100m',value:12.5,date:'2026-04-20'}]};
  assert.equal((await api('/api/state',{method:'PUT',cookie:first.cookie,body:{state,revision:0}})).json.revision,1);
  const conflict=await api('/api/state',{method:'PUT',cookie:first.cookie,body:{state:{wrong:true},revision:0}});
  assert.equal(conflict.status,409);
  assert.deepEqual(conflict.json.state,state);
  const second=await api('/api/auth/register',{method:'POST',body:{name:'Athlète B',email:'b@example.com',password:'autre-motdepasse'}});
  assert.deepEqual((await api('/api/state',{cookie:second.cookie})).json,{state:null,revision:0});
  assert.equal((await api('/api/auth/register',{method:'POST',body:{name:'Athlète A',email:'A@EXAMPLE.COM',password:'motdepasse-solide'}})).status,409);
  await api('/api/auth/logout',{method:'POST',cookie:first.cookie});
  assert.equal((await api('/api/state',{cookie:first.cookie})).status,401);
  assert.equal((await api('/api/auth/login',{method:'POST',body:{email:'a@example.com',password:'incorrect'}})).status,401);
  const login=await api('/api/auth/login',{method:'POST',body:{email:'A@example.com',password:'motdepasse-solide'}});
  assert.equal(login.status,200);
  assert.deepEqual((await api('/api/state',{cookie:login.cookie})).json.state,state);
});

test('validation rejects unsafe state, cross-origin mutations and FFA relay requests',async t=>{
  const {api}=await setup(t);
  assert.equal((await api('/api/auth/register',{method:'POST',body:{name:'X',email:'wrong',password:'short'}})).status,400);
  assert.equal((await api('/api/auth/login',{method:'POST',body:{},headers:{Origin:'https://example.org'}})).status,403);
  assert.equal((await api('/api/ffa/import',{method:'POST',body:{url:'https://localhost/'}})).status,401);
  const user=await api('/api/auth/register',{method:'POST',body:{name:'Athlète',email:'test@example.org',password:'longpassword123'}});
  assert.equal((await api('/api/state',{method:'PUT',cookie:user.cookie,body:{state:[],revision:0}})).status,400);
  assert.equal((await api('/api/state',{method:'PUT',cookie:user.cookie,body:{state:{},revision:-1}})).status,400);
  const badUrl=await api('/api/ffa/import',{method:'POST',cookie:user.cookie,body:{url:'https://bases.athle.fr.evil.example/asp.net/athletes.aspx?seq=123'}});
  assert.equal(badUrl.status,400);
  assert.equal(badUrl.json.code,'FFA_URL_INVALID');
  assert.equal((await api('/api/ffa/search?surname=a',{cookie:user.cookie})).status,400);
  assert.equal((await api('/api/missing')).status,404);
});

test('password login rate limits are enforced',async t=>{
  const {api}=await setup(t,{rateLimit:true});
  for(let i=0;i<15;i++) assert.equal((await api('/api/auth/register',{method:'POST',body:{}})).status,400);
  assert.equal((await api('/api/auth/register',{method:'POST',body:{}})).status,429);
});

test('FFA marks, dates and event normalization preserve numeric units',()=>{
  assert.equal(canonicalEvent('100 m'), '100m');
  assert.equal(canonicalEvent('110m Haies (106) / TCM'),'110mh');
  assert.equal(canonicalEvent('Longueur / TCF'),'long');
  assert.equal(parseMark("10''68",'100m'),10.68);
  assert.equal(parseMark("3'45''67",'1500m'),225.67);
  assert.equal(parseMark("1h02'34''",'half'),3754);
  assert.equal(parseMark('7m15','long'),7.15);
  assert.equal(parseMark('45,62','discus'),45.62);
  assert.equal(parseMark('DNF','100m'),null);
  assert.equal(parseMark("3'75''00",'1500m'),null);
  assert.equal(parseDate('14/06/2026'),'2026-06-14');
  assert.equal(parseDate('31/02/26'),null);
});

test('FFA parsing imports dated event rows and merge remains idempotent',()=>{
  const url='https://bases.athle.fr/asp.net/athletes.aspx?base=bilans&seq=123';
  const html=`<!doctype html><html><head><title>Fiche athlète</title></head><body><h1>Athlète de test</h1><span class="athlete-club">Club exemple</span><table>
    <tr><th>Épreuve</th><th>Perf.</th><th>Vent</th><th>Date</th><th>Lieu</th></tr>
    <tr><td>100m</td><td>10''68</td><td>+1.2</td><td>14/06/2026</td><td>Paris</td></tr>
    <tr><td>Longueur</td><td>7m15</td><td>-0.3</td><td>15/06/2026</td><td>Lyon</td></tr>
    <tr><td>100m</td><td>DNF</td><td></td><td>16/06/2026</td><td>Paris</td></tr>
    <tr><td>100m</td><td>10''68</td><td>+1.2</td><td>14/06/2026</td><td>Paris</td></tr>
    <tr><td>Classement</td><td>12</td><td></td><td>14/06/2026</td><td>Paris</td></tr>
    </table></body></html>`;
  const imported=parseAthleteHtml(html,url);
  assert.equal(imported.performances.length,2);
  assert.equal(imported.athlete.name,'Athlète de test');
  assert.equal(imported.performances[0].event,'long');
  assert.equal(imported.performances[0].value,7.15);
  assert.equal(imported.performances[1].wind,1.2);
  assert.equal(mergePerformances(imported.performances,imported.performances).length,2);
  assert.throws(()=>parseAthleteHtml('<html><title>Page vide</title></html>',url),error=>error.code==='FFA_FORMAT_CHANGED');
});

test('FFA URL allowlist blocks credentials, ports and internal addresses',()=>{
  const valid='https://bases.athle.fr/asp.net/athletes.aspx?base=bilans&seq=123';
  assert.equal(String(validateFfaUrl(valid)),valid);
  for(const value of ['http://bases.athle.fr/asp.net/athletes.aspx?seq=123','https://bases.athle.fr@127.0.0.1/athletes/123','https://bases.athle.fr:444/asp.net/athletes.aspx?seq=123','https://bases.athle.fr/other','file:///etc/passwd','https://example.com/athletes/123']) assert.throws(()=>validateFfaUrl(value));
});
