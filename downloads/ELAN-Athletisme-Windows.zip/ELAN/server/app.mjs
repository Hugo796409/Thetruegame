import express from 'express';
import { randomUUID } from 'node:crypto';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { root, openDb, readState, writeState } from './db.mjs';
import { createSession, hashPassword, loadUser, publicUser, sessionToken, tokenHash, verifyPassword } from './auth.mjs';
import { importAthlete, searchAthletes, FfaError } from './ffa.mjs';

export function createApp({ db = openDb(), secureCookies = process.env.ELAN_SECURE_COOKIES === '1', rateLimit = true } = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req,res,next)=>{
    res.set({ 'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY', 'Referrer-Policy':'strict-origin-when-cross-origin' });
    if (req.path.startsWith('/api/')) res.set('Cache-Control','no-store');
    // CSRF protection: require same origin. The explicit local Vite exception is
    // available only outside production; production cookies are never sent cross-site.
    if (!['GET','HEAD','OPTIONS'].includes(req.method) && req.headers.origin) {
      let allowed = false;
      try {
        const origin = new URL(req.headers.origin);
        allowed = origin.host === req.headers.host || origin.origin === process.env.ELAN_PUBLIC_ORIGIN ||
          (process.env.NODE_ENV !== 'production' && ['localhost','127.0.0.1'].includes(origin.hostname) && ['localhost','127.0.0.1'].includes(new URL(`http://${req.headers.host}`).hostname));
      } catch {}
      if (!allowed) return res.status(403).json({ error:'Cette requête ne provient pas de l’application.' });
    }
    next();
  });
  app.use(express.json({ limit:'2mb', strict:true }));
  const authAttempts = new Map();
  const ffaAttempts = new Map();
  function limit(map, maximum, windowMs) {
    return (req,res,next)=>{
      if (!rateLimit) return next();
      const key = req.socket.remoteAddress || 'local';
      const now = Date.now();
      // Bound memory even when many different addresses connect over time.
      if (map.size > 2000) for (const [k,v] of map) if (v.reset <= now) map.delete(k);
      let entry = map.get(key);
      if (!entry || entry.reset <= now) { entry = {count:0,reset:now+windowMs}; map.set(key,entry); }
      if (++entry.count > maximum) {
        res.set('Retry-After',String(Math.ceil((entry.reset-now)/1000)));
        return res.status(429).json({error:'Trop de tentatives. Patiente quelques minutes avant de réessayer.'});
      }
      next();
    };
  }
  const authenticate = (req,res,next)=>{
    req.user = loadUser(db,req);
    if (!req.user) return res.status(401).json({error:'Connecte-toi à ton compte ÉLAN pour synchroniser tes données et utiliser la FFA.'});
    next();
  };

  app.get('/api/health', (_req,res)=>res.json({status:'ok',app:'ÉLAN',version:'1.0.0'}));
  app.get('/api/auth/me', (req,res)=>{const user=loadUser(db,req);res.json({user:user ? publicUser(user) : null});});
  app.post('/api/auth/register',limit(authAttempts,15,15*60_000),async(req,res,next)=>{
    try {
      const name = String(req.body?.name || '').trim();
      const email = String(req.body?.email || '').trim().toLowerCase();
      const password = req.body?.password;
      if (name.length < 2 || name.length > 80 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || typeof password !== 'string' || password.length < 10 || password.length > 200)
        return res.status(400).json({error:'Indique un nom (2 à 80 caractères), un e-mail valide et un mot de passe de 10 à 200 caractères.'});
      const id = randomUUID();
      const passwordHash = await hashPassword(password);
      try { db.prepare('INSERT INTO users(id,email,name,password_hash,created_at) VALUES(?,?,?,?,?)').run(id,email,name,passwordHash,Date.now()); }
      catch (error) {
        if (String(error.message).includes('UNIQUE')) return res.status(409).json({error:'Cet e-mail est déjà utilisé. Connecte-toi à ton compte.'});
        throw error;
      }
      createSession(db,id,res,secureCookies);
      res.status(201).json({user:{id,name,email}});
    } catch(error) {next(error);}
  });
  app.post('/api/auth/login',limit(authAttempts,15,15*60_000),async(req,res,next)=>{
    try {
      const email = String(req.body?.email || '').trim().toLowerCase();
      const password = req.body?.password;
      if (typeof password !== 'string' || password.length > 200 || email.length > 254) return res.status(400).json({error:'Identifiants invalides.'});
      const user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
      // Run a real scrypt for unknown users too, avoiding a timing-based lookup.
      const candidate = user?.password_hash || 'scrypt:00000000000000000000000000000000:'+'00'.repeat(64);
      const valid = await verifyPassword(password,candidate);
      if (!user || !valid) return res.status(401).json({error:'E-mail ou mot de passe incorrect.'});
      const old = sessionToken(req);
      if (old) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(old));
      createSession(db,user.id,res,secureCookies);
      res.json({user:publicUser(user)});
    } catch(error) {next(error);}
  });
  app.post('/api/auth/logout',(req,res)=>{
    const token=sessionToken(req);
    if(token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(token));
    res.clearCookie('elan_session',{httpOnly:true,sameSite:'lax',secure:secureCookies,path:'/'});
    res.json({ok:true});
  });
  app.get('/api/state',authenticate,(req,res)=>res.json(readState(db,req.user.id)));
  app.put('/api/state',authenticate,(req,res,next)=>{
    const {state,revision}=req.body || {};
    if (!state || typeof state !== 'object' || Array.isArray(state) || !Number.isSafeInteger(revision) || revision<0)
      return res.status(400).json({error:'La sauvegarde doit contenir un état et une révision valides.'});
    try {
      const nextRevision=writeState(db,req.user.id,state,revision);
      if(nextRevision===null) return res.status(409).json({error:'Une version plus récente existe sur le serveur. Recharge les données avant de réessayer.',code:'STATE_CONFLICT',...readState(db,req.user.id)});
      res.json({revision:nextRevision});
    } catch(error) {next(error);}
  });
  app.get('/api/ffa/search',authenticate,limit(ffaAttempts,12,60_000),async(req,res,next)=>{
    const surname=String(req.query.surname || req.query.name || '').trim();
    const givenName=String(req.query.givenName || '').trim();
    const club=String(req.query.club || '').trim();
    const year=Number(req.query.year || new Date().getFullYear());
    if(surname.length<2 || surname.length>100 || givenName.length>100 || club.length>100 || !Number.isInteger(year) || year<1990 || year>new Date().getFullYear()+1)
      return res.status(400).json({error:'Indique un nom d’au moins 2 caractères et une saison valide.'});
    try {res.json(await searchAthletes(surname,givenName,club,year));} catch(error){next(error);}
  });
  app.post('/api/ffa/import',authenticate,limit(ffaAttempts,12,60_000),async(req,res,next)=>{
    if(typeof req.body?.url!=='string' || req.body.url.length>2000) return res.status(400).json({error:'Indique un lien de fiche FFA valide.'});
    try {res.json(await importAthlete(req.body.url));} catch(error){next(error);}
  });
  app.use('/api',(_req,res)=>res.status(404).json({error:'Cette fonction API n’existe pas.'}));
  const dist=resolve(root,'dist');
  if(existsSync(resolve(dist,'index.html'))) {
    app.use(express.static(dist,{index:false}));
    app.get('/{*path}',(_req,res)=>res.sendFile(resolve(dist,'index.html')));
  }
  app.use((error,_req,res,_next)=>{
    if(error instanceof FfaError) return res.status(error.code==='FFA_URL_INVALID'?400:502).json({error:error.message,code:error.code,sourceUrl:error.sourceUrl});
    if(error.type==='entity.too.large') return res.status(413).json({error:'La sauvegarde dépasse 2 Mo. Exporte tes données et réduis les pièces jointes.'});
    if(error instanceof SyntaxError && error.status===400) return res.status(400).json({error:'Le document JSON est invalide.'});
    console.error('ÉLAN server:',error.message);
    res.status(500).json({error:'Une erreur serveur est survenue. Tes données précédemment sauvegardées restent conservées.'});
  });
  return {app,db};
}
