import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const defaultDbPath = resolve(process.env.ELAN_DATA_DIR || resolve(root, 'data'), 'elan.sqlite');

export function openDb(path = process.env.ELAN_DB_PATH || defaultDbPath) {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
      password_hash TEXT NOT NULL, created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS athlete_states (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      state_json TEXT, revision INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
    );`);
  return db;
}

export function readState(db, userId) {
  const row = db.prepare('SELECT state_json, revision FROM athlete_states WHERE user_id = ?').get(userId);
  return { state: row?.state_json ? JSON.parse(row.state_json) : null, revision: row?.revision || 0 };
}

export function writeState(db, userId, state, revision) {
  // A transaction and revision check protect browser saves and CLI imports alike.
  db.exec('BEGIN IMMEDIATE');
  try {
    const existing = db.prepare('SELECT revision FROM athlete_states WHERE user_id = ?').get(userId);
    if ((existing?.revision || 0) !== revision) {
      db.exec('ROLLBACK');
      return null;
    }
    const next = revision + 1;
    db.prepare(`INSERT INTO athlete_states(user_id, state_json, revision, updated_at) VALUES (?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET state_json=excluded.state_json, revision=excluded.revision, updated_at=excluded.updated_at`)
      .run(userId, JSON.stringify(state), next, Date.now());
    db.exec('COMMIT');
    return next;
  } catch (error) { db.exec('ROLLBACK'); throw error; }
}
