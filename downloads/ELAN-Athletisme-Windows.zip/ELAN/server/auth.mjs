import { randomBytes, scrypt as scryptCallback, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCallback);
export const SESSION_AGE = 30 * 24 * 60 * 60 * 1000;
export const tokenHash = value => createHash('sha256').update(value).digest('hex');
export const publicUser = row => ({ id: row.id, name: row.name, email: row.email });

export async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const result = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${result.toString('hex')}`;
}

export async function verifyPassword(password, encoded) {
  const [algorithm, salt, key] = String(encoded).split(':');
  if (algorithm !== 'scrypt' || !salt || !key) return false;
  const candidate = await scrypt(password, salt, 64);
  const expected = Buffer.from(key, 'hex');
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

export function createSession(db, userId, res, secure = false) {
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
  const token = randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token_hash, user_id, expires_at) VALUES (?, ?, ?)')
    .run(tokenHash(token), userId, Date.now() + SESSION_AGE);
  res.cookie('elan_session', token, { httpOnly: true, sameSite: 'lax', secure, maxAge: SESSION_AGE, path: '/' });
}

export function sessionToken(req) {
  const match = String(req.headers.cookie || '').match(/(?:^|;\s*)elan_session=([a-f0-9]{64})(?:;|$)/);
  return match?.[1] || null;
}

export function loadUser(db, req) {
  const token = sessionToken(req);
  return token ? db.prepare(`SELECT users.* FROM sessions JOIN users ON users.id = sessions.user_id
    WHERE sessions.token_hash = ? AND sessions.expires_at > ?`).get(tokenHash(token), Date.now()) : null;
}
