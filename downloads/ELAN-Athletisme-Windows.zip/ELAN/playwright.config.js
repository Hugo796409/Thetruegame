import {defineConfig} from '@playwright/test';
import {existsSync} from 'node:fs';
export default defineConfig({testDir:'./tests',fullyParallel:false,workers:1,timeout:45000,expect:{timeout:7000},reporter:[['list'],['html',{open:'never'}]],use:{baseURL:'http://127.0.0.1:4173',headless:true,viewport:{width:1440,height:1050},launchOptions:{executablePath:process.env.CHROMIUM_PATH||(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined),args:['--no-sandbox']},screenshot:'only-on-failure',trace:'retain-on-failure'}});
