# ÉLAN — Ton terrain de progression

Application d’athlétisme en français, conçue pour Windows et utilisable dans un navigateur : entraînement modifiable, performances, académie technique, récupération et aventure gamifiée.

Commencer : **[LISEZ-MOI.md](LISEZ-MOI.md)**. Sur Windows, installer Node.js 24 LTS puis exécuter `INSTALLER.cmd` et `DEMARRER.cmd`.

- 39 cours originaux avec exercices et quiz ; 41 exercices ; 41 épreuves.
- Cycles de 4 semaines selon niveau, spécialités, âge, matériel, disponibilités et dernier bilan forme ; séances du coach modifiables.
- Chronomètre, temps de récupération, journal, RPE, objectifs et suivi des performances.
- Comptes indépendants, SQLite, synchronisation avec un serveur commun et gestion des conflits.
- Import/export CSV, sauvegarde/restauration JSON, sauvegarde cohérente SQLite.
- Quêtes quotidiennes, XP, niveaux, badges, révisions et phrases motivantes.
- Interface animée, polices locales, thème sombre et réduction des animations.

## Limites vérifiées

Le connecteur FFA est implémenté et testé sur des fixtures, mais **la compatibilité du site en direct n’a pas pu être vérifiée** : l’environnement cloud refuse l’accès FFA. L’import CSV et la saisie manuelle sont testés. Aucun résultat n’est inventé. Seules les lignes datées reconnues de la page sélectionnée sont importées ; l’ensemble des saisons n’est pas garanti.

Les comptes partagent les données entre appareils connectés au même serveur. Aucun hébergement Internet n’est créé automatiquement ; voir [le guide](docs/HEBERGEMENT.md).

Les programmes sont des trames pédagogiques. Le niveau performance et les spécialités à risque nécessitent un entraîneur qualifié ; l’application ne remplace pas une évaluation individuelle.

## Développement et tests

```sh
npm ci
npm run build
npm start
# Autre terminal :
npm test
```

Développement avec rechargement : `npm run server`, puis `npm run dev` dans un autre terminal. Tests navigateur : serveur actif, `npm run test:e2e`. Installer le navigateur avec `npx playwright install chromium`, puis définir `CHROMIUM_PATH` vers son exécutable si Chromium n’est pas à `/usr/bin/chromium`.

[Rapport de validation](docs/VALIDATION.md). Les commandes Windows sont relues mais n’ont pas été exécutées sur Windows dans cet environnement Linux.
