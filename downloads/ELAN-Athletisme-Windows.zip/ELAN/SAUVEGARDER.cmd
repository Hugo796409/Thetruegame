@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title ELAN - Sauvegarde
where node >nul 2>nul
if errorlevel 1 goto :failed
node --env-file-if-exists=.env scripts/backup.mjs
if errorlevel 1 goto :failed
echo.
echo Conservez une copie du dossier backups sur un autre support.
pause
exit /b 0

:failed
echo.
echo Sauvegarde impossible. Consultez le message ci-dessus.
echo Node.js 24 LTS et une base ELAN existante sont necessaires.
pause
exit /b 1
