@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title ELAN - Serveur
where node >nul 2>nul
if errorlevel 1 goto :not_installed
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"
if errorlevel 1 goto :not_installed
if not exist "node_modules\express\package.json" goto :not_installed
if not exist "dist\index.html" goto :not_installed
echo.
echo  ELAN / Votre espace d'entrainement
echo  ==================================
echo.
echo Le navigateur s'ouvrira quand le serveur sera disponible.
echo Gardez cette fenetre ouverte pendant votre utilisation.
echo Pour arreter : Ctrl+C, puis confirmez si Windows le demande.
echo.
start "ELAN - ouverture navigateur" /b node --env-file-if-exists=.env scripts/open-browser.mjs
call npm start
if errorlevel 1 goto :failed
exit /b 0

:not_installed
echo Lancez d'abord INSTALLER.cmd. Node.js 24 LTS est necessaire.
pause
exit /b 1

:failed
echo.
echo Le serveur s'est arrete sur une erreur. Consultez le message ci-dessus.
echo Si le port est deja utilise, fermez l'autre instance d'ELAN.
pause
exit /b 1
