@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title ELAN - Installation
echo.
echo  ELAN / Installation des dependances
echo  ===================================
echo.
where node >nul 2>nul
if errorlevel 1 goto :node_missing
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"
if errorlevel 1 goto :node_missing
where npm >nul 2>nul
if errorlevel 1 goto :node_missing
echo [1/2] Installation exacte des dependances verrouillees...
call npm ci
if errorlevel 1 goto :failed
echo.
echo [2/2] Preparation de l'application...
call npm run build
if errorlevel 1 goto :failed
echo.
echo Installation terminee. Double-cliquez sur DEMARRER.cmd.
echo Conservez cette fenetre si vous souhaitez lire le resultat.
pause
exit /b 0

:node_missing
echo.
echo Node.js 24 LTS ou plus recent est necessaire.
echo Installez la version Windows depuis https://nodejs.org/en/download
echo Fermez puis rouvrez ce fichier apres l'installation.
pause
exit /b 1

:failed
echo.
echo L'installation a echoue. Les messages ci-dessus expliquent l'erreur.
echo Verifiez votre connexion Internet puis relancez INSTALLER.cmd.
pause
exit /b 1
