# ÉLAN — votre progression prend de l'élan

Une application d'athlétisme en français, à installer sur votre ordinateur. Elle rassemble votre profil sportif, vos entraînements, vos performances, vos formations et vos défis dans un même espace.

## Démarrage sur Windows 10 ou 11

1. **Extrayez tout le ZIP** dans un dossier de votre choix, par exemple `Documents\ELAN`. N'exécutez pas les fichiers à l'intérieur du ZIP.
2. Installez **Node.js 24 LTS** ou plus récent depuis [le site officiel Node.js](https://nodejs.org/en/download), avec les options d'installation par défaut. Si Node.js est déjà présent, `node --version` doit afficher au moins `v24`.
3. Double-cliquez sur **`INSTALLER.cmd`**. Il installe les versions exactes des dépendances puis construit l'application. Une connexion Internet est nécessaire pour cette étape.
4. Double-cliquez sur **`DEMARRER.cmd`**. Le navigateur s'ouvre quand le serveur répond. Son adresse habituelle est `http://127.0.0.1:4173`.
5. Gardez la fenêtre du serveur ouverte. Pour arrêter l'application, utilisez **Ctrl+C** dans cette fenêtre.

Ouvrez toujours l'application par son adresse HTTP. Un double-clic sur `dist/index.html` ne permet pas d'utiliser les comptes ni l'enregistrement des données.

## Premiers pas

Renseignez votre profil : spécialités, niveau, disponibilités et matériel. Les propositions de séances utilisent ces paramètres ; vous pouvez les modifier et intégrer les consignes de votre entraîneur. Adaptez progressivement votre profil à votre pratique réelle. Le niveau « performance » reste un outil de préparation à ajuster avec votre encadrement.

Créez un compte pour conserver vos données dans la base du serveur et retrouver ce compte sur les appareils connectés au même serveur. Un compte est propre à cette installation d'ÉLAN : il n'est pas un compte FFA. Aucun mot de passe FFA n'est demandé.

Les contenus techniques sont des formations originales accompagnées de sources pour approfondir. Les jours de récupération font partie de la progression ; les récompenses ne demandent pas de s'entraîner malgré une douleur.

## Comptes et synchronisation entre appareils

**Le serveur de votre ordinateur est le point commun.** Les appareils synchronisent leurs données en se connectant au même serveur ; deux copies du ZIP lancées séparément possèdent deux bases distinctes.

Sur le même réseau Wi-Fi ou Ethernet :

1. Lancez ÉLAN sur l'ordinateur qui conservera vos données.
2. Sur cet ordinateur, ouvrez une invite de commandes et tapez `ipconfig` pour trouver son adresse IPv4 locale, par exemple `192.168.1.25`.
3. Sur l'autre appareil, ouvrez `http://192.168.1.25:4173` en remplaçant l'adresse par la vôtre, puis connectez-vous au même compte.
4. Si Windows demande un accès au pare-feu, autorisez Node.js uniquement sur votre **réseau privé**. L'ordinateur serveur doit rester allumé et le serveur actif.

La synchronisation nécessite une connexion au serveur. Il n'y a pas d'hébergement Internet automatique, de service payant obligatoire ni de sauvegarde distante automatique. Pour un accès hors de chez vous, voir [le guide d'hébergement](docs/HEBERGEMENT.md).

## Performances FFA

L'intégration travaille sur les pages publiques des résultats FFA. Dans l'application, recherchez l'athlète avec son identité et son club, puis vérifiez la fiche proposée avant de la lier. Une homonymie ne doit pas créer de rapprochement automatique. Vous pouvez aussi renseigner directement le lien public de la fiche si la recherche est indisponible.

**`SYNCHRONISER-FFA.cmd`** relance l'import des profils déjà liés aux comptes de cette installation. Les performances existantes sont conservées et les doublons reconnus. Actualisez l'application après la commande pour charger les données enregistrées sur le serveur.

L'accès dépend du site FFA, de sa disponibilité et de son format. Si le site bloque l'accès automatisé ou change son format, la commande explique l'échec ; cela ne signifie pas qu'aucune performance n'existe. Un import manuel CSV et la saisie restent les solutions de repli proposées par l'application. Le fonctionnement du parseur sur des données de test et une synchronisation réellement exécutée sur le site FFA sont deux vérifications distinctes : consultez le rapport de validation livré avec cette version pour connaître ce qui a été vérifié.

La commande met à jour les comptes liés, pas des données conservées uniquement dans un mode de démonstration. Elle ne publie aucune performance sur la FFA et ne modifie pas votre fiche officielle.

## Sauvegarder et restaurer

Double-cliquez sur **`SAUVEGARDER.cmd`**. Une copie cohérente et vérifiée de la base est créée dans `backups/`, y compris si le serveur est actif. Copiez régulièrement cette sauvegarde sur un autre support.

Le fichier par défaut est `data/elan.sqlite`. Il contient les comptes et les données sportives. Les mots de passe sont dérivés cryptographiquement, mais les journaux sportifs restent lisibles par une personne ayant accès à la base : protégez ce dossier et vos sauvegardes avec les permissions Windows appropriées. Ne publiez pas ces fichiers sur un dépôt Git.

Pour restaurer une sauvegarde :

1. Arrêtez tous les processus ÉLAN et la commande de synchronisation.
2. Conservez une copie de l'ensemble du dossier `data/` existant.
3. Remplacez `data/elan.sqlite` par votre fichier de sauvegarde en le renommant `elan.sqlite`.
4. Si d'anciens fichiers `elan.sqlite-wal` et `elan.sqlite-shm` subsistent, déplacez-les dans votre copie de sécurité avant de redémarrer : ils ne doivent pas être associés à une base restaurée différente.
5. Redémarrez ÉLAN. Vous retrouvez les comptes et données au moment de la sauvegarde.

Si vous avez configuré `ELAN_DB_PATH` ou `ELAN_DATA_DIR`, appliquez ces étapes à cet emplacement.

## Réglages facultatifs

Copiez `.env.example` en `.env` pour changer le port, le dossier de données ou l'adresse d'écoute. Les commandes fournies chargent ce fichier au démarrage. Il n'est pas nécessaire de créer `.env` pour une utilisation normale.

Après une mise à jour du code ou des dépendances, arrêtez le serveur puis relancez `INSTALLER.cmd`. **Ne remplacez pas vos dossiers `data/` et `backups/` par ceux d'une autre installation.** Le ZIP de distribution ne doit contenir aucune donnée personnelle.

## En cas de problème

| Symptôme | Action |
| --- | --- |
| « node n'est pas reconnu » | Installez Node.js 24 LTS, fermez la fenêtre puis relancez la commande. |
| Échec pendant `npm ci` | Vérifiez la connexion Internet, le proxy éventuel et le message d'erreur ; relancez l'installation sans supprimer le fichier de verrouillage. |
| Port déjà utilisé | Fermez l'autre fenêtre ÉLAN ou choisissez un autre `PORT` dans `.env`. |
| La page ne s'ouvre pas | Gardez la fenêtre du serveur ouverte et ouvrez manuellement l'adresse affichée. |
| Données différentes sur deux appareils | Vérifiez que vous utilisez le même serveur et le même compte. |
| FFA indisponible | Consultez le message d'import, vérifiez le lien officiel et utilisez l'import manuel si nécessaire. |
| La commande disparaît trop vite | Ouvrez une invite dans le dossier du projet puis lancez la commande pour lire sa sortie. |

## Pour développer

Depuis le dossier du projet : `npm ci`, puis `npm run dev` pour l'interface et `npm run server` pour l'API si le mode de développement les lance séparément. Consultez `package.json` pour les scripts exacts. Pour utiliser le résultat construit : `npm run build`, puis `npm start`.

Les tests et leurs limites sont consignés dans le rapport de validation fourni avec la livraison. Les commandes Windows doivent être exécutées sur Windows pour vérifier leur intégration avec votre installation et votre navigateur.
