@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title ELAN - Mise a jour FFA
where node >nul 2>nul
if errorlevel 1 goto :not_installed
if not exist "node_modules\express\package.json" goto :not_installed
echo.
echo  ELAN / Synchronisation des profils FFA lies
echo  ===========================================
echo.
echo Les profils doivent avoir ete lies depuis l'application.
echo Une connexion Internet est necessaire. Aucune performance n'est inventee.
echo.
call npm run sync:ffa
if errorlevel 1 goto :failed
echo.
echo Synchronisation terminee. Actualisez l'application si elle est ouverte.
pause
exit /b 0

:not_installed
echo Lancez d'abord INSTALLER.cmd et creez votre compte dans l'application.
pause
exit /b 1

:failed
echo.
echo Une synchronisation n'a pas abouti. Consultez les details ci-dessus.
echo Les donnees deja enregistrees restent conservees.
pause
exit /b 1
