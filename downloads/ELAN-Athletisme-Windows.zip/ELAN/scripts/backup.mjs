import { DatabaseSync, backup } from 'node:sqlite';
import { mkdir, chmod, access } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = process.env.ELAN_DB_PATH
  ? resolve(process.env.ELAN_DB_PATH)
  : resolve(process.env.ELAN_DATA_DIR || resolve(root, 'data'), 'elan.sqlite');
const outputDir = resolve(root, 'backups');
const timestamp = new Date().toISOString().replaceAll(':', '-').replaceAll('.', '-');
const output = resolve(outputDir, `elan-${timestamp}.sqlite`);
let database;
try {
  await access(source);
  await mkdir(outputDir, { recursive: true, mode: 0o700 });
  database = new DatabaseSync(source, { readOnly: true });
  await backup(database, output);
  await chmod(output, 0o600);
  const snapshot = new DatabaseSync(output, { readOnly: true });
  try {
    const check = snapshot.prepare('PRAGMA quick_check').get();
    if (check.quick_check !== 'ok') throw new Error('Le contrôle SQLite de la sauvegarde a échoué.');
  } finally {
    snapshot.close();
  }
  console.log(`Sauvegarde SQLite vérifiée : ${output}`);
  console.log('Elle contient vos comptes et données personnelles. Conservez-la dans un endroit protégé.');
} catch (error) {
  console.error(`Sauvegarde impossible : ${error.message}`);
  if (error.code === 'ENOENT') console.error('Lancez ELAN et créez un compte avant de sauvegarder.');
  process.exitCode = 1;
} finally {
  database?.close();
}
