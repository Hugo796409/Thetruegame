import { execFile } from 'node:child_process';

const port = Number(process.env.PORT || 4173);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('PORT invalide : ouverture automatique du navigateur annulée.');
  process.exit(1);
}
const origin = `http://127.0.0.1:${port}`;
let opened = false;
for (let attempt = 0; attempt < 60; attempt += 1) {
  try {
    const response = await fetch(`${origin}/api/health`, { signal: AbortSignal.timeout(1000) });
    if (response.ok) {
      if (process.platform === 'win32') {
        execFile('cmd.exe', ['/d', '/c', 'start', '', origin], { windowsHide: true }, (error) => {
          if (error) console.error(`Ouvrez ${origin} dans votre navigateur.`);
        });
      } else if (process.platform === 'darwin') {
        execFile('open', [origin], () => {});
      } else {
        console.log(`ELAN disponible : ${origin}`);
      }
      opened = true;
      break;
    }
  } catch {
    // The foreground server is still starting; readiness is checked again below.
  }
  await new Promise((resolve) => setTimeout(resolve, 500));
}
if (!opened) console.error(`Le serveur n'a pas répondu. Consultez sa fenêtre puis ouvrez ${origin}.`);
