import { openDb, readState, writeState } from '../server/db.mjs';
import { importAthlete, mergePerformances } from '../server/ffa.mjs';

const args=process.argv.slice(2);
const emailIndex=args.indexOf('--email');
const selectedEmail=emailIndex>=0?args[emailIndex+1]:null;
const dryRun=args.includes('--dry-run');
if(emailIndex>=0 && (!selectedEmail || selectedEmail.startsWith('--'))) {
  console.error('Usage : npm run sync:ffa -- [--email nom@example.com] [--dry-run]');process.exit(1);
}
const db=openDb();
let failures=0;
try {
  const users=selectedEmail?db.prepare('SELECT id,email FROM users WHERE email=?').all(selectedEmail.toLowerCase()):db.prepare('SELECT id,email FROM users').all();
  if(selectedEmail && users.length===0) {console.error('Aucun compte ne correspond à cet e-mail sur ce serveur.');failures++;}
  let linked=0;
  for(const user of users) {
    const {state,revision}=readState(db,user.id);
    if(!state?.ffa?.url) continue;
    linked++;
    try {
      const result=await importAthlete(state.ffa.url);
      const old=Array.isArray(state.performances)?state.performances:[];
      const merged=mergePerformances(old,result.performances);
      const added=merged.length-old.length;
      if(!dryRun) {
        // Refuse to overwrite edits made while the network request was running.
        const updated=writeState(db,user.id,{...state,performances:merged,ffa:{...state.ffa,url:result.athlete.url,lastSync:result.fetchedAt}},revision);
        if(updated===null) throw new Error('Les données ont changé pendant l’import. Relance la commande pour fusionner la version récente.');
      }
      console.log(`${dryRun?'[Simulation] ':''}Profil ${linked} : ${result.performances.length} résultat(s) lu(s), ${added} nouveau(x).`);
    } catch(error) {failures++;console.error(`Profil ${linked} : ${error.message}`);}
  }
  if(!linked) console.log('Aucun profil FFA lié. Connecte-toi à ÉLAN puis lie une fiche depuis la page Performances.');
} finally {db.close();}
process.exitCode=failures?1:0;
