import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import '@fontsource-variable/dm-sans';
import '@fontsource/instrument-serif/400-italic.css';
import './styles.css';
createRoot(document.getElementById('root')).render(<App/>);
