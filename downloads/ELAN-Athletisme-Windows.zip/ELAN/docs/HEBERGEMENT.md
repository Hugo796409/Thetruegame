# Utiliser le même compte au-delà du réseau local

ÉLAN contient un serveur et une base SQLite : ce sont eux qui assurent l'authentification et la synchronisation entre appareils. Le ZIP n'inclut pas un hébergement distant déjà provisionné.

Pour une utilisation personnelle sur votre réseau privé, le lancement Windows habituel suffit. Pour rendre le service accessible sur Internet, déployez une instance unique du projet sur une machine que vous contrôlez et utilisez un domaine avec **HTTPS**. Un hébergeur ou un administrateur peut mettre en place :

- Node.js 24 LTS, `npm ci`, `npm run build` et un service supervisé exécutant `npm start` ;
- un volume persistant pour `data/` et des sauvegardes régulières hors de la machine ;
- un proxy inverse HTTPS, par exemple Caddy ou nginx, vers le port interne 4173 ;
- `HOST=127.0.0.1` si le proxy est sur la même machine, et `ELAN_SECURE_COOKIES=1` pour les cookies HTTPS ;
- un pare-feu limitant l'exposition publique aux ports du proxy et une configuration correcte des en-têtes transmis ;
- une vérification des sauvegardes, des mises à jour et des droits d'accès au dossier des données.

Tous les appareils doivent ouvrir le **même domaine** et utiliser le même compte. Ne placez pas la base SQLite sur un dossier de synchronisation OneDrive/Dropbox ni sur un partage réseau pour tenter de fusionner plusieurs serveurs : cela ne constitue pas un mécanisme de réplication.

L'application ne fournit pas de récupération de mot de passe par email ni d'envoi d'emails sans infrastructure dédiée. Conservez votre accès et vos sauvegardes. Avant d'ouvrir l'inscription à d'autres personnes ou d'en faire un service public, prévoyez une exploitation, des contrôles de sécurité et des informations de confidentialité adaptés.

La configuration d'un serveur Internet n'a pas été exécutée dans le ZIP : la livraison permet l'exécution locale et l'accès au serveur partagé, et documente l'étape d'hébergement restante.
