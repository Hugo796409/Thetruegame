# Validation de la version 1.0.0

Validation effectuée le 28 octobre 2026, heure de Paris, dans un environnement Linux avec Node.js 24.19.0 et Chromium. Ce rapport décrit des opérations effectivement exécutées ; il ne constitue pas une validation Windows ou un déploiement Internet.

## Vérifications réussies

- Installation sur une copie de distribution neuve : `npm ci`, compilation et les 27 tests réussis sans dépendances ni données préinstallées.
- Compilation de production avec `npm run build` : réussie. Tous les composants et les polices sont inclus localement dans `dist/`.
- **27 tests métier et serveur** avec `npm test` : tous réussis, aucun ignoré. Ils couvrent comptes, mots de passe dérivés, cookies, connexion/déconnexion, isolation des comptes, conflits de révision, protection contre les mutations d’origine externe, limitation des tentatives, validation des liens FFA, parseur FFA sur fixtures, CSV, unités et temps, sauvegardes JSON invalides, adaptation des programmes, repos entre séances exigeantes, mineurs, matériel, fatigue, disponibilité, compétition et cohérence du catalogue.
- **8 tests de parcours Chromium** avec Playwright : tous réussis. Ils couvrent profil et persistance, bilan forme, quêtes, objectifs, préférences, compte récupéré depuis une seconde session indépendante, 7 rubriques à 1 440 / 1 024 / 390 pixels sans débordement horizontal, cours, quiz, révisions sans double XP, séances personnalisées, chronomètre, récupération, débrief, performances manuelles, graphique, modification, suppression, import CSV partiel signalé, dédoublonnage, export et erreur FFA explicite sans compte.
- Captures de l’accueil, du planning, de l’académie et des performances inspectées. Ajustement des tailles et contrastes, noms accessibles des contrôles, navigation au clavier des modales, option de réduction des animations et thème sombre.
- Sauvegarde SQLite sur la base de validation active : créée avec l’API de sauvegarde SQLite et vérifiée par `PRAGMA quick_check`.
- Commande FFA `--dry-run` sans profil lié : affiche le prérequis et n’invente aucune donnée. Ce contrôle ne valide pas un import FFA en direct.
- Audit des dépendances de production : **0 vulnérabilité signalée** au moment du contrôle. Ce résultat dépend de la base d’avis du registre et ne remplace pas une revue de sécurité.

Les comptes créés pour les tests, leurs bases SQLite, leurs sauvegardes et les données navigateur de test sont exclus de l’archive distribuée.

## Limites qui restent explicites

**FFA.** Les accès HTTPS aux pages FFA ont été refusés par le proxy de l’environnement cloud. Recherche et import sont implémentés, protégés et testés sur des exemples HTML ; ils ne sont pas certifiés compatibles avec les pages FFA actuelles. Un changement de structure du site peut nécessiter une adaptation du connecteur. Le lien de profil et l’import ne promettent pas toutes les saisons : seules les lignes datées reconnues de la page sont traitées. CSV et saisie manuelle restent disponibles et ont été testés.

**Windows.** Les fichiers `.cmd` sont enregistrés en CRLF, utilisent le dossier du script, contrôlent les erreurs et les prérequis. Ils ont été relus mais n’ont pas été exécutés dans un environnement Windows. Node.js 24 LTS doit être installé. Les opérations npm et serveur sous-jacentes ont été exécutées sur Linux.

**Synchronisation.** La synchronisation a été vérifiée entre deux contextes navigateur connectés au même serveur et à la même base. Elle exige un serveur commun actif. Aucun compte hébergé sur un service cloud public, aucun nom de domaine et aucun certificat HTTPS ne sont provisionnés par le ZIP. Le guide d’hébergement explique cette étape si vous souhaitez un accès distant.

**Personnalisation sportive.** Les programmes sont des trames pédagogiques conservatrices, adaptables et éditables ; ils ne remplacent pas le plan individuel d’un entraîneur, notamment au niveau professionnel, pour les mineurs ou les retours après blessure. Les contenus sont originaux et n’ont pas été validés par une fédération. Les liens de ressources ne constituent pas une certification.

**Références visuelles et documentaires.** Les sites Apple, Ciao Kombucha et certaines sources institutionnelles ont également été bloqués par le réseau. Le design est une création originale à partir de la direction souhaitée : typographie éditoriale, surfaces calmes, illustration locale de piste, accent vif, animations et transitions. Aucun média distant indispensable au fonctionnement n’est intégré.
