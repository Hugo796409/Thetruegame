import {test,expect} from '@playwright/test';

test.describe('Carnet de performances',()=>{
  let browserErrors;
  test.beforeEach(async({page})=>{
    browserErrors=[];
    page.on('pageerror',error=>browserErrors.push(error.message));
    await page.goto('/');
    await page.getByRole('button',{name:'Mes performances',exact:true}).click();
    await expect(page.getByRole('heading',{name:'Chaque marque compte.'})).toBeVisible();
  });
  test.afterEach(async()=>{expect(browserErrors).toEqual([]);});
  async function addMark(page,{event='100m',mark,date,venue='Stade de test',wind=''}={}) {
    await page.getByRole('button',{name:'Ajouter une performance',exact:true}).click();
    const dialog=page.getByRole('dialog',{name:'Une nouvelle marque'});
    await dialog.getByLabel('Épreuve',{exact:true}).selectOption(event);
    await dialog.getByLabel('Date',{exact:true}).fill(date);
    await dialog.getByLabel(/^Performance/).fill(mark);
    await dialog.getByLabel(/^Lieu/).fill(venue);
    if(wind)await dialog.getByLabel(/^Vent/).fill(wind);
    await dialog.getByRole('button',{name:'Enregistrer',exact:true}).click();
    await expect(dialog).not.toBeVisible();
  }
  test('saisit, modifie, trace deux marques puis supprime une marque avec confirmation',async({page})=>{
    await expect(page.getByText('La ligne de départ est ici.')).toBeVisible();
    await expect(page.getByText('Ajoute au moins deux résultats sur cette épreuve pour tracer ta courbe.')).toBeVisible();
    await addMark(page,{mark:'12,34',date:'2025-06-01',wind:'1,2'});
    let rows=page.locator('.performance-table tbody tr');
    await expect(rows).toHaveCount(1);
    await expect(rows.first()).toContainText('12,34 s');
    await expect(rows.first()).toContainText('1.2 m/s');
    await page.getByRole('button',{name:/Modifier la performance/}).click();
    const edit=page.getByRole('dialog',{name:'Modifier une performance'});
    await edit.getByLabel(/^Performance/).fill('12,10');
    await edit.getByRole('button',{name:'Enregistrer',exact:true}).click();
    await expect(rows.first()).toContainText('12,10 s');
    await addMark(page,{mark:'11,98',date:'2025-07-01'});
    await expect(rows).toHaveCount(2);
    await expect(page.locator('.performance-chart svg circle')).toHaveCount(2);
    await expect(page.locator('.performance-stat').first()).toContainText('11,98 s');
    await page.getByRole('button',{name:/Supprimer la performance/}).first().click();
    const deletion=page.getByRole('dialog',{name:'Supprimer cette marque ?'});
    await deletion.getByRole('button',{name:'Conserver'}).click();
    await expect(rows).toHaveCount(2);
    await page.getByRole('button',{name:/Supprimer la performance/}).first().click();
    await page.getByRole('dialog',{name:'Supprimer cette marque ?'}).getByRole('button',{name:'Supprimer',exact:true}).click();
    await expect(rows).toHaveCount(1);
    await page.reload();
    await page.getByRole('button',{name:'Mes performances',exact:true}).click();
    await expect(page.locator('.performance-table tbody tr')).toHaveCount(1);
    await expect(page.locator('.performance-table tbody tr')).toContainText('12,10 s');
  });
  test('importe le CSV valide, signale les erreurs, filtre les épreuves et saisons et exporte',async({page})=>{
    const csv='epreuve;performance;date;lieu;vent\r\n100m;12,34;2025-06-01;Lyon;1,0\r\n100m;12,10;2024-06-01;Paris;-0,5\r\nlong;6,45;2025-06-02;Lyon;1,2\r\n100m;0;2025-06-03;Erreur;\r\n';
    await page.locator('input[type="file"][accept=".csv,text/csv"]').setInputFiles({name:'performances.csv',mimeType:'text/csv',buffer:Buffer.from(csv,'utf8')});
    const dialog=page.getByRole('dialog',{name:'Vérifier l’import CSV'});
    await expect(dialog).toContainText('3 lignes valides');
    await expect(dialog).toContainText('1 ligne à corriger');
    await expect(dialog).toContainText('Ligne 5');
    await dialog.getByRole('button',{name:'Importer les lignes valides'}).click();
    await expect(page.locator('.performance-table tbody tr')).toHaveCount(2);
    await page.getByLabel('Saison',{exact:true}).selectOption('2024');
    await expect(page.locator('.performance-table tbody tr')).toHaveCount(1);
    await expect(page.locator('.performance-table tbody tr')).toContainText('12,10 s');
    await page.getByLabel('Épreuve',{exact:true}).selectOption('long');
    await expect(page.locator('.performance-table tbody tr')).toHaveCount(1);
    await expect(page.locator('.performance-table tbody tr')).toContainText('6,45 m');
    const downloaded=page.waitForEvent('download');
    await page.getByRole('button',{name:'Exporter',exact:true}).click();
    const file=await downloaded;
    expect(file.suggestedFilename()).toMatch(/^elan-performances-.*\.csv$/);
    await page.locator('input[type="file"][accept=".csv,text/csv"]').setInputFiles({name:'performances.csv',mimeType:'text/csv',buffer:Buffer.from(csv,'utf8')});
    await page.getByRole('dialog',{name:'Vérifier l’import CSV'}).getByRole('button',{name:'Importer les lignes valides'}).click();
    await expect(page.locator('.performance-table tbody tr')).toHaveCount(2);
  });
  test('FFA affiche une vraie erreur de compte sans inventer de résultats',async({page})=>{
    await page.getByRole('button',{name:'FFA Bilans'}).click();
    await page.getByLabel('Nom',{exact:true}).fill('DUPONT');
    await page.getByLabel('Prénom',{exact:true}).fill('Jean');
    await page.getByRole('button',{name:'Rechercher',exact:true}).click();
    await expect(page.locator('.performance-error')).toBeVisible();
    await expect(page.locator('.performance-error')).toContainText(/connect|compte|authentifi/i);
    await expect(page.locator('.performance-table tbody tr')).toHaveCount(0);
  });
});
